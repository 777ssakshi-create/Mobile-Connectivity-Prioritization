"""Mobile connectivity prioritisation package."""
